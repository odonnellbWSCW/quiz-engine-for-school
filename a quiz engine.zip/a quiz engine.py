#importing stuff
import json
import os

def clear_console(loops):
    for o in range(loops):
        print("\n")
    # Check if the operating system is Windows
    if os.name == 'nt':
        os.system('cls')
    # For Unix/Linux/Mac
    else:
        os.system('clear')

#main answer checker, body of the quiz
def ask(question, answer):
    temp=input(question + "\n")
    ok=False
    options=answer.split('~')
    for q in options:
        if (q.lower()).strip()==(temp.lower()).strip():
            ok=True
            break
    if ok:
        return(1)
    else:
        return(0)
while True:
    #initaialise score
    score=0

    # Clear the console
    clear_console(20)

    print("\n" + "pick a quiz to load by typing its id (eg. 1 = quiz1.json)" + "\n")

    #prints avalable quiz files (80% chatgpt)
    current_directory = os.getcwd()
    data_directory = os.path.join(current_directory, 'data')
    files = os.listdir(data_directory)
    files = [f for f in files if os.path.isfile(os.path.join(data_directory, f))]
    for k in range(len(files)):
        print(k+1, "-", files[k])

         
    #quiz selection
    print("")

    while True:
        try:
            t = int(input(""))
            break
        except ValueError:
            print("value out of range, enter an integer")

    quiz = files[t-1]
    print("")


    #finds quiz file (also mostly gpt)
    file_path = os.path.join('data', quiz)
    with open(file_path, 'r') as file:
        data = json.load(file)

    #loads quiz file
    questions = data['questions']
    answers = data['answers']
    if 'message' in data:
        print(data['message'] + "\n")

    #main loop
    for i in range(len(questions)):
        score+=ask(questions[i], answers[i])

    #end
    print("\nyou finnished the quiz with a score of", score, "/", len(questions))
    r=input("\npress enter to try another quiz or type 'q' to quit\n")
    if r=='q':
        break
